import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

api.interceptors.response.use(
  r => r,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// Auth
export const authApi = {
  login: (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
};

// Tickets
export const ticketsApi = {
  getAll: (params) => api.get('/tickets', { params }),
  getById: (id) => api.get(`/tickets/${id}`),
  create: (data) => api.post('/tickets', data),
  update: (id, data) => api.put(`/tickets/${id}`, data),
  delete: (id) => api.delete(`/tickets/${id}`),
  changeStatus: (id, data) => api.patch(`/tickets/${id}/status`, data),
  assign: (id, data) => api.patch(`/tickets/${id}/assign`, data),
  addComment: (id, data) => api.post(`/tickets/${id}/comments`, data),
  deleteComment: (ticketId, commentId) => api.delete(`/tickets/${ticketId}/comments/${commentId}`),
};

// Categories
export const categoriesApi = {
  getAll: () => api.get('/categories'),
  create: (data) => api.post('/categories', data),
  update: (id, data) => api.put(`/categories/${id}`, data),
  delete: (id) => api.delete(`/categories/${id}`),
};

// Users
export const usersApi = {
  getAll: () => api.get('/users'),
  getAgents: () => api.get('/users/agents'),
  update: (id, data) => api.put(`/users/${id}`, data),
  delete: (id) => api.delete(`/users/${id}`),
};

// Stats
export const statsApi = {
  get: () => api.get('/stats'),
};

// Attachments
export const attachmentsApi = {
  upload: (ticketId, file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post(`/tickets/${ticketId}/attachments`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  download: (ticketId, id) => api.get(`/tickets/${ticketId}/attachments/${id}/download`, { responseType: 'blob' }),
  delete: (ticketId, id) => api.delete(`/tickets/${ticketId}/attachments/${id}`),
};

export default api;
