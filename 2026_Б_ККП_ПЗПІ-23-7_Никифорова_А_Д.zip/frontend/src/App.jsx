import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import Layout from './components/Layout'
import LoginPage from './pages/LoginPage'
import TicketsPage from './pages/TicketsPage'
import TicketDetailPage from './pages/TicketDetailPage'
import CreateTicketPage from './pages/CreateTicketPage'
import StatsPage from './pages/StatsPage'
import UsersPage from './pages/UsersPage'
import CategoriesPage from './pages/CategoriesPage'

function PrivateRoute({ children, roles }) {
  const { user, isAdmin, isAgent } = useAuth()
  if (!user) return <Navigate to="/login" replace />
  if (roles?.includes('Admin') && !isAdmin) return <Navigate to="/tickets" replace />
  if (roles?.includes('Agent') && !isAgent) return <Navigate to="/tickets" replace />
  return children
}

export default function App() {
  const { user } = useAuth()
  if (!user) return <Routes><Route path="*" element={<LoginPage />} /></Routes>

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Navigate to="/tickets" replace />} />
        <Route path="/tickets" element={<PrivateRoute><TicketsPage /></PrivateRoute>} />
        <Route path="/tickets/new" element={<PrivateRoute><CreateTicketPage /></PrivateRoute>} />
        <Route path="/tickets/:id" element={<PrivateRoute><TicketDetailPage /></PrivateRoute>} />
        <Route path="/stats" element={<PrivateRoute roles={['Agent']}><StatsPage /></PrivateRoute>} />
        <Route path="/users" element={<PrivateRoute roles={['Admin']}><UsersPage /></PrivateRoute>} />
        <Route path="/categories" element={<PrivateRoute roles={['Admin']}><CategoriesPage /></PrivateRoute>} />
        <Route path="*" element={<Navigate to="/tickets" replace />} />
      </Routes>
    </Layout>
  )
}
