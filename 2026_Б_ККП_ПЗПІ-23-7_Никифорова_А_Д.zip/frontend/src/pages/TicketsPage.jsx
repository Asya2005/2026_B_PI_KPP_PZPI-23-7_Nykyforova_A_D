import { useState, useEffect, useCallback } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ticketsApi, categoriesApi } from '../api'
import { StatusBadge, PriorityBadge, OverdueBadge, Spinner, Pagination, formatDate } from '../components/shared'
import { useAuth } from '../context/AuthContext'

const STATUSES = [
  { value: '', label: 'Всі статуси' },
  { value: '0', label: 'Нова' },
  { value: '1', label: 'В роботі' },
  { value: '2', label: 'Очікує відповіді' },
  { value: '3', label: 'Вирішена' },
  { value: '4', label: 'Закрита' },
  { value: '5', label: 'Відхилена' },
]
const PRIORITIES = [
  { value: '', label: 'Всі пріоритети' },
  { value: '0', label: 'Низький' },
  { value: '1', label: 'Середній' },
  { value: '2', label: 'Високий' },
  { value: '3', label: 'Критичний' },
]

export default function TicketsPage() {
  const { isAgent } = useAuth()
  const navigate = useNavigate()
  const [data, setData] = useState(null)
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({ Status: '', Priority: '', CategoryId: '', Search: '', Page: 1, PageSize: 15, SortBy: 'createdAt', SortDesc: true })

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''))
      const { data: d } = await ticketsApi.getAll(params)
      setData(d)
    } finally { setLoading(false) }
  }, [filters])

  useEffect(() => { load() }, [load])
  useEffect(() => { categoriesApi.getAll().then(r => setCategories(r.data)) }, [])

  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v, Page: 1 }))

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <h2 style={{ fontSize: 20, fontWeight: 700 }}>Заявки</h2>
          {data && <p style={{ color: 'var(--text2)', fontSize: 13, marginTop: 2 }}>Всього: {data.totalCount}</p>}
        </div>
        <button className="btn btn-primary" onClick={() => navigate('/tickets/new')}>+ Нова заявка</button>
      </div>

      <div className="filters">
        <input className="form-control" placeholder="🔍 Пошук..." value={filters.Search}
          onChange={e => setFilter('Search', e.target.value)} style={{ minWidth: 200 }} />
        <select className="form-control" value={filters.Status} onChange={e => setFilter('Status', e.target.value)}>
          {STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        <select className="form-control" value={filters.Priority} onChange={e => setFilter('Priority', e.target.value)}>
          {PRIORITIES.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
        </select>
        <select className="form-control" value={filters.CategoryId} onChange={e => setFilter('CategoryId', e.target.value)}>
          <option value="">Всі категорії</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select className="form-control" value={`${filters.SortBy}_${filters.SortDesc}`}
          onChange={e => { const [b, d] = e.target.value.split('_'); setFilters(f => ({ ...f, SortBy: b, SortDesc: d === 'true', Page: 1 })) }}>
          <option value="createdAt_true">Дата ↓</option>
          <option value="createdAt_false">Дата ↑</option>
          <option value="priority_true">Пріоритет ↓</option>
          <option value="priority_false">Пріоритет ↑</option>
        </select>
      </div>

      <div className="card" style={{ padding: 0 }}>
        {loading ? <Spinner /> : !data?.items?.length ? (
          <div className="empty"><p>Заявок не знайдено</p></div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Заголовок</th>
                <th>Категорія</th>
                <th>Статус</th>
                <th>Пріоритет</th>
                <th>Автор</th>
                {isAgent && <th>Виконавець</th>}
                <th>Дата</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map(t => (
                <tr key={t.id} onClick={() => navigate(`/tickets/${t.id}`)} style={{ cursor: 'pointer' }}>
                  <td style={{ color: 'var(--text3)', fontSize: 12 }}>#{t.id}</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontWeight: 600, fontSize: 13.5 }}>{t.title}</span>
                      {t.isOverdue && <OverdueBadge />}
                    </div>
                    {t.commentCount > 0 && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>💬 {t.commentCount}</div>}
                  </td>
                  <td><span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: t.category.color, marginRight: 6 }} />{t.category.name}</td>
                  <td><StatusBadge status={t.status} label={t.statusLabel} /></td>
                  <td><PriorityBadge priority={t.priority} label={t.priorityLabel} /></td>
                  <td style={{ fontSize: 13 }}>{t.createdBy.name}</td>
                  {isAgent && <td style={{ fontSize: 13 }}>{t.assignedTo?.name ?? <span style={{ color: 'var(--text3)' }}>—</span>}</td>}
                  <td style={{ fontSize: 12, color: 'var(--text2)' }}>{formatDate(t.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      {data && <Pagination page={data.page} totalPages={data.totalPages} onChange={p => setFilters(f => ({ ...f, Page: p }))} />}
    </div>
  )
}
