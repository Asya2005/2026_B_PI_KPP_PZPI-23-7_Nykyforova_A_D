// CreateTicketPage
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ticketsApi, categoriesApi } from '../api'

export function CreateTicketPage() {
  const navigate = useNavigate()
  const [form, setForm] = useState({ title: '', description: '', priority: 1, categoryId: '' })
  const [categories, setCategories] = useState([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => { categoriesApi.getAll().then(r => { setCategories(r.data); if (r.data[0]) setForm(f => ({ ...f, categoryId: r.data[0].id })) }) }, [])

  const submit = async e => {
    e.preventDefault(); setError(''); setLoading(true)
    try {
      const { data } = await ticketsApi.create({ ...form, priority: parseInt(form.priority), categoryId: parseInt(form.categoryId) })
      navigate(`/tickets/${data.id}`)
    } catch { setError('Помилка створення заявки') } finally { setLoading(false) }
  }

  return (
    <div style={{ maxWidth: 640 }}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 20 }}>Нова заявка</h2>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="card">
        <form onSubmit={submit}>
          <div className="form-group">
            <label className="form-label">Заголовок *</label>
            <input className="form-control" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Коротко опишіть проблему" required />
          </div>
          <div className="form-group">
            <label className="form-label">Опис *</label>
            <textarea className="form-control" rows={5} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Детальний опис проблеми..." required />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div className="form-group">
              <label className="form-label">Категорія *</label>
              <select className="form-control" value={form.categoryId} onChange={e => setForm(f => ({ ...f, categoryId: e.target.value }))} required>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Пріоритет *</label>
              <select className="form-control" value={form.priority} onChange={e => setForm(f => ({ ...f, priority: e.target.value }))}>
                <option value={0}>Низький</option>
                <option value={1}>Середній</option>
                <option value={2}>Високий</option>
                <option value={3}>Критичний</option>
              </select>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <button type="button" className="btn btn-secondary" onClick={() => navigate('/tickets')}>Скасувати</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Збереження...' : 'Створити заявку'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CreateTicketPage
