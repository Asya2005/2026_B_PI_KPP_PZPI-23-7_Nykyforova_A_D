import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function LoginPage() {
  const { login, register } = useAuth()
  const [tab, setTab] = useState('login')
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const submit = async e => {
    e.preventDefault()
    setError(''); setLoading(true)
    try {
      if (tab === 'login') await login(form.email, form.password)
      else await register(form.name, form.email, form.password)
    } catch (err) {
      setError(err.response?.data?.message || 'Помилка авторизації')
    } finally { setLoading(false) }
  }

  return (
    <div className="auth-page">
      <div className="auth-card card">
        <div className="auth-logo">
          <h1>🛡️ Service Desk</h1>
          <p>Система обліку звернень</p>
        </div>
        <div className="auth-tabs">
          <button className={`auth-tab ${tab === 'login' ? 'active' : ''}`} onClick={() => setTab('login')}>Увійти</button>
          <button className={`auth-tab ${tab === 'reg' ? 'active' : ''}`} onClick={() => setTab('reg')}>Реєстрація</button>
        </div>
        {error && <div className="alert alert-error">{error}</div>}
        <form onSubmit={submit}>
          {tab === 'reg' && (
            <div className="form-group">
              <label className="form-label">Ім'я</label>
              <input className="form-control" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Введіть ім'я" required />
            </div>
          )}
          <div className="form-group">
            <label className="form-label">Email</label>
            <input className="form-control" type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="email@example.com" required />
          </div>
          <div className="form-group">
            <label className="form-label">Пароль</label>
            <input className="form-control" type="password" value={form.password} onChange={e => set('password', e.target.value)} placeholder="••••••••" required />
          </div>
          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} disabled={loading}>
            {loading ? 'Завантаження...' : tab === 'login' ? 'Увійти' : 'Зареєструватись'}
          </button>
        </form>
      </div>
    </div>
  )
}
