import { useState, useEffect } from 'react'
import { usersApi } from '../api'
import { Spinner, Modal } from '../components/shared'

const ROLES = [{ value: 0, label: 'Користувач' }, { value: 1, label: 'Агент' }, { value: 2, label: 'Адміністратор' }]

export default function UsersPage() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState({})

  const load = () => usersApi.getAll().then(r => { setUsers(r.data); setLoading(false) })
  useEffect(() => { load() }, [])

  const openEdit = u => { setEditing(u); setForm({ name: u.name, email: u.email, role: u.role, isActive: u.isActive }) }
  const save = async () => {
    await usersApi.update(editing.id, form)
    setEditing(null); load()
  }
  const del = async id => { if (confirm('Видалити користувача?')) { await usersApi.delete(id); load() } }

  if (loading) return <Spinner />

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 20 }}>Користувачі ({users.length})</h2>
      <div className="card" style={{ padding: 0 }}>
        <table className="table">
          <thead><tr><th>#</th><th>Ім'я</th><th>Email</th><th>Роль</th><th>Статус</th><th>Дії</th></tr></thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id}>
                <td style={{ color: 'var(--text3)', fontSize: 12 }}>{u.id}</td>
                <td style={{ fontWeight: 600 }}>{u.name}</td>
                <td style={{ color: 'var(--text2)', fontSize: 13 }}>{u.email}</td>
                <td><span className="badge" style={{ background: 'var(--bg3)' }}>{ROLES.find(r => r.value === u.role)?.label ?? u.role}</span></td>
                <td><span className={`badge ${u.isActive ? 'badge-resolved' : 'badge-rejected'}`}>{u.isActive ? 'Активний' : 'Неактивний'}</span></td>
                <td>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => openEdit(u)}>✏️</button>
                    <button className="btn btn-danger btn-sm" onClick={() => del(u.id)}>🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing && (
        <Modal title={`Редагувати: ${editing.name}`} onClose={() => setEditing(null)}
          footer={<>
            <button className="btn btn-secondary" onClick={() => setEditing(null)}>Скасувати</button>
            <button className="btn btn-primary" onClick={save}>Зберегти</button>
          </>}>
          <div className="form-group">
            <label className="form-label">Ім'я</label>
            <input className="form-control" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input className="form-control" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">Роль</label>
            <select className="form-control" value={form.role} onChange={e => setForm(f => ({ ...f, role: parseInt(e.target.value) }))}>
              {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontSize: 14 }}>
              <input type="checkbox" checked={form.isActive} onChange={e => setForm(f => ({ ...f, isActive: e.target.checked }))} />
              Активний акаунт
            </label>
          </div>
        </Modal>
      )}
    </div>
  )
}
