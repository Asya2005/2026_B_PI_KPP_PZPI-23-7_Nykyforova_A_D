import { useState, useEffect } from 'react'
import { categoriesApi } from '../api'
import { Spinner, Modal } from '../components/shared'

const COLORS = ['#6366f1','#0ea5e9','#10b981','#f59e0b','#ef4444','#8b5cf6','#ec4899','#14b8a6']

export default function CategoriesPage() {
  const [cats, setCats] = useState([])
  const [loading, setLoading] = useState(true)
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState({ name: '', description: '', color: '#6366f1', isActive: true })

  const load = () => categoriesApi.getAll().then(r => { setCats(r.data); setLoading(false) })
  useEffect(() => { load() }, [])

  const openNew = () => { setEditing(null); setForm({ name: '', description: '', color: '#6366f1', isActive: true }); setModal(true) }
  const openEdit = c => { setEditing(c); setForm({ name: c.name, description: c.description, color: c.color, isActive: c.isActive }); setModal(true) }

  const save = async () => {
    if (editing) await categoriesApi.update(editing.id, form)
    else await categoriesApi.create(form)
    setModal(false); load()
  }
  const del = async id => { if (confirm('Видалити категорію?')) { await categoriesApi.delete(id); load() } }

  if (loading) return <Spinner />

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 700 }}>Категорії</h2>
        <button className="btn btn-primary" onClick={openNew}>+ Нова категорія</button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 }}>
        {cats.map(c => (
          <div key={c.id} className="card" style={{ borderLeft: `4px solid ${c.color}` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 15 }}>{c.name}</div>
                <div style={{ color: 'var(--text2)', fontSize: 13, marginTop: 4 }}>{c.description}</div>
              </div>
              <div style={{ display: 'flex', gap: 4 }}>
                <button className="btn btn-ghost btn-sm btn-icon" onClick={() => openEdit(c)}>✏️</button>
                <button className="btn btn-danger btn-sm btn-icon" onClick={() => del(c.id)}>🗑️</button>
              </div>
            </div>
            <div style={{ marginTop: 12 }}>
              <span className={`badge ${c.isActive ? 'badge-resolved' : 'badge-closed'}`}>{c.isActive ? 'Активна' : 'Неактивна'}</span>
            </div>
          </div>
        ))}
      </div>

      {modal && (
        <Modal title={editing ? 'Редагувати категорію' : 'Нова категорія'} onClose={() => setModal(false)}
          footer={<>
            <button className="btn btn-secondary" onClick={() => setModal(false)}>Скасувати</button>
            <button className="btn btn-primary" onClick={save}>Зберегти</button>
          </>}>
          <div className="form-group">
            <label className="form-label">Назва</label>
            <input className="form-control" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">Опис</label>
            <input className="form-control" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">Колір</label>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 4 }}>
              {COLORS.map(col => (
                <button key={col} onClick={() => setForm(f => ({ ...f, color: col }))}
                  style={{ width: 32, height: 32, borderRadius: '50%', background: col, border: form.color === col ? '3px solid white' : '3px solid transparent', outline: form.color === col ? `2px solid ${col}` : 'none' }} />
              ))}
            </div>
          </div>
          {editing && (
            <div className="form-group">
              <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontSize: 14 }}>
                <input type="checkbox" checked={form.isActive} onChange={e => setForm(f => ({ ...f, isActive: e.target.checked }))} />
                Активна категорія
              </label>
            </div>
          )}
        </Modal>
      )}
    </div>
  )
}
