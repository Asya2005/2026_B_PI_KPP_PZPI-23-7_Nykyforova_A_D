import { useState, useEffect } from 'react'
import { statsApi } from '../api'
import { Spinner } from '../components/shared'

export default function StatsPage() {
  const [stats, setStats] = useState(null)
  useEffect(() => { statsApi.get().then(r => setStats(r.data)) }, [])
  if (!stats) return <Spinner />

  const total = stats.totalTickets || 1
  const bars = [
    { label: 'Нові', count: stats.newTickets, color: '#818cf8' },
    { label: 'В роботі', count: stats.inProgressTickets, color: '#fbbf24' },
    { label: 'Вирішені', count: stats.resolvedTickets, color: '#34d399' },
    { label: 'Закриті', count: stats.closedTickets, color: '#94a3b8' },
  ]

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 20 }}>Статистика</h2>
      <div className="stat-grid">
        {[
          { label: 'Всього заявок', value: stats.totalTickets, color: 'var(--primary)' },
          { label: 'Нових', value: stats.newTickets, color: '#818cf8' },
          { label: 'В роботі', value: stats.inProgressTickets, color: '#fbbf24' },
          { label: 'Вирішено', value: stats.resolvedTickets, color: '#34d399' },
          { label: 'Закрито', value: stats.closedTickets, color: '#94a3b8' },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div className="card">
          <h3 style={{ fontWeight: 700, marginBottom: 16 }}>По статусу</h3>
          {bars.map(b => (
            <div key={b.label} style={{ marginBottom: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13 }}>
                <span>{b.label}</span><span style={{ fontWeight: 700, color: b.color }}>{b.count}</span>
              </div>
              <div style={{ height: 8, background: 'var(--bg3)', borderRadius: 4, overflow: 'hidden' }}>
                <div style={{ height: '100%', background: b.color, borderRadius: 4, width: `${Math.round(b.count / total * 100)}%`, transition: 'width .5s' }} />
              </div>
            </div>
          ))}
        </div>

        <div className="card">
          <h3 style={{ fontWeight: 700, marginBottom: 16 }}>По категоріях</h3>
          {stats.byCategory.length === 0 ? <p style={{ color: 'var(--text3)', fontSize: 13 }}>Немає даних</p> :
            stats.byCategory.map(c => (
              <div key={c.name} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                  <span style={{ width: 12, height: 12, borderRadius: '50%', background: c.color, display: 'inline-block' }} />
                  {c.name}
                </div>
                <span style={{ fontWeight: 700, fontSize: 14 }}>{c.count}</span>
              </div>
            ))}
        </div>

        <div className="card" style={{ gridColumn: '1 / -1' }}>
          <h3 style={{ fontWeight: 700, marginBottom: 16 }}>По агентах</h3>
          {stats.byAgent.length === 0 ? <p style={{ color: 'var(--text3)', fontSize: 13 }}>Немає даних</p> : (
            <table className="table">
              <thead><tr><th>Агент</th><th>Призначено</th><th>Вирішено</th><th>Ефективність</th></tr></thead>
              <tbody>
                {stats.byAgent.map(a => (
                  <tr key={a.name}>
                    <td style={{ fontWeight: 600 }}>{a.name}</td>
                    <td>{a.assigned}</td>
                    <td style={{ color: '#34d399' }}>{a.resolved}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ flex: 1, height: 6, background: 'var(--bg3)', borderRadius: 3, overflow: 'hidden' }}>
                          <div style={{ height: '100%', background: '#34d399', width: `${a.assigned ? Math.round(a.resolved / a.assigned * 100) : 0}%` }} />
                        </div>
                        <span style={{ fontSize: 12, color: 'var(--text2)', minWidth: 35 }}>{a.assigned ? Math.round(a.resolved / a.assigned * 100) : 0}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}
