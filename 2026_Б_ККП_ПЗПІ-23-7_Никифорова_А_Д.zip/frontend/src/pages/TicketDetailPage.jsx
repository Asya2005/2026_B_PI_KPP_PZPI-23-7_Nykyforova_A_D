import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ticketsApi, usersApi, attachmentsApi } from '../api'
import { StatusBadge, PriorityBadge, OverdueBadge, Spinner, Modal, formatDate, formatFileSize } from '../components/shared'
import { useAuth } from '../context/AuthContext'

const STATUSES = [
  { value: 0, label: 'Нова' }, { value: 1, label: 'В роботі' },
  { value: 2, label: 'Очікує відповіді' }, { value: 3, label: 'Вирішена' },
  { value: 4, label: 'Закрита' }, { value: 5, label: 'Відхилена' },
]

export default function TicketDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { user, isAgent, isAdmin } = useAuth()
  const [ticket, setTicket] = useState(null)
  const [agents, setAgents] = useState([])
  const [loading, setLoading] = useState(true)
  const [forbidden, setForbidden] = useState(false)
  const [comment, setComment] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [statusModal, setStatusModal] = useState(false)
  const [statusForm, setStatusForm] = useState({ newStatus: 1, note: '' })
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState('')
  const fileInputRef = useRef(null)

  const load = async () => {
    try {
      const { data } = await ticketsApi.getById(id)
      setTicket(data)
    } catch (err) {
      if (err.response?.status === 403) setForbidden(true)
      // 404 falls through: ticket stays null, handled by the existing "not found" state below
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [id])
  useEffect(() => { if (isAgent) usersApi.getAgents().then(r => setAgents(r.data)) }, [isAgent])

  const addComment = async () => {
    if (!comment.trim()) return
    setSubmitting(true)
    await ticketsApi.addComment(id, { text: comment })
    setComment('')
    await load()
    setSubmitting(false)
  }

  const changeStatus = async () => {
    await ticketsApi.changeStatus(id, { newStatus: statusForm.newStatus, note: statusForm.note })
    setStatusModal(false)
    await load()
  }

  const assignAgent = async (agentId) => {
    await ticketsApi.assign(id, { agentId: agentId ? parseInt(agentId) : null })
    await load()
  }

  const deleteTicket = async () => {
    if (confirm('Видалити заявку?')) {
      await ticketsApi.delete(id)
      navigate('/tickets')
    }
  }

  const uploadFile = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadError('')
    setUploading(true)
    try {
      await attachmentsApi.upload(id, file)
      await load()
    } catch (err) {
      setUploadError(err.response?.data?.message || 'Не вдалося завантажити файл')
    } finally {
      setUploading(false)
      if (fileInputRef.current) fileInputRef.current.value = ''
    }
  }

  const downloadFile = async (attachment) => {
    const { data } = await attachmentsApi.download(id, attachment.id)
    const url = window.URL.createObjectURL(new Blob([data]))
    const link = document.createElement('a')
    link.href = url
    link.download = attachment.fileName
    document.body.appendChild(link)
    link.click()
    link.remove()
    window.URL.revokeObjectURL(url)
  }

  const deleteAttachment = async (attachmentId) => {
    if (!confirm('Видалити файл?')) return
    await attachmentsApi.delete(id, attachmentId)
    await load()
  }

  if (loading) return <Spinner />
  if (forbidden) return <div className="empty"><p>Немає доступу до цієї заявки</p></div>
  if (!ticket) return <div className="empty"><p>Заявку не знайдено</p></div>

  return (
    <div>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 20, flexWrap: 'wrap' }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/tickets')}>← Назад</button>
        <h2 style={{ flex: 1, fontSize: 18, fontWeight: 700 }}>#{ticket.id} — {ticket.title}</h2>
        {ticket.isOverdue && <OverdueBadge />}
        {isAgent && <button className="btn btn-secondary btn-sm" onClick={() => { setStatusForm({ newStatus: ticket.status, note: '' }); setStatusModal(true) }}>Змінити статус</button>}
        {isAdmin && <button className="btn btn-danger btn-sm" onClick={deleteTicket}>Видалити</button>}
      </div>

      <div className="ticket-detail">
        <div className="ticket-body">
          {/* Description */}
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: 12 }}>Опис</h3>
            <p style={{ color: 'var(--text2)', lineHeight: 1.8, whiteSpace: 'pre-wrap' }}>{ticket.description}</p>
          </div>

          {/* Attachments */}
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: 16 }}>Вкладення ({ticket.attachments?.length ?? 0})</h3>
            {(!ticket.attachments || ticket.attachments.length === 0) && (
              <p style={{ color: 'var(--text3)', fontSize: 13 }}>Файлів ще немає</p>
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {ticket.attachments?.map(a => (
                <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: '1px solid var(--border, #2a2a2a)' }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <button
                      onClick={() => downloadFile(a)}
                      style={{ background: 'none', border: 'none', padding: 0, color: 'var(--primary, #6366f1)', cursor: 'pointer', fontSize: 14, fontWeight: 600, textAlign: 'left', wordBreak: 'break-all' }}
                    >
                      📎 {a.fileName}
                    </button>
                    <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>
                      {formatFileSize(a.fileSizeBytes)} · {a.uploadedBy.name} · {formatDate(a.uploadedAt)}
                    </div>
                  </div>
                  {(isAdmin || a.uploadedBy.id === user?.id) && (
                    <button className="btn btn-ghost btn-sm" onClick={() => deleteAttachment(a.id)}>Видалити</button>
                  )}
                </div>
              ))}
            </div>
            <div style={{ marginTop: 16 }}>
              <input
                ref={fileInputRef}
                type="file"
                onChange={uploadFile}
                disabled={uploading}
                style={{ fontSize: 13 }}
              />
              {uploading && <span style={{ fontSize: 13, color: 'var(--text3)', marginLeft: 8 }}>Завантаження...</span>}
              {uploadError && <p style={{ color: '#f87171', fontSize: 13, marginTop: 8 }}>{uploadError}</p>}
              <p style={{ color: 'var(--text3)', fontSize: 12, marginTop: 8 }}>Максимальний розмір файлу — 10 МБ</p>
            </div>
          </div>

          {/* Comments */}
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: 16 }}>Коментарі ({ticket.comments.length})</h3>
            {ticket.comments.length === 0 && <p style={{ color: 'var(--text3)', fontSize: 13 }}>Коментарів ще немає</p>}
            <div className="comments">
              {ticket.comments.map(c => (
                <div key={c.id} className="comment">
                  <div className="comment-header">
                    <span className="comment-author">{c.user.name}</span>
                    <span className="comment-date">{formatDate(c.createdAt)}</span>
                  </div>
                  <p className="comment-text">{c.text}</p>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 16, display: 'flex', gap: 10, flexDirection: 'column' }}>
              <textarea className="form-control" rows={3} placeholder="Написати коментар..." value={comment} onChange={e => setComment(e.target.value)} />
              <button className="btn btn-primary btn-sm" style={{ alignSelf: 'flex-end' }} onClick={addComment} disabled={submitting || !comment.trim()}>
                {submitting ? '...' : 'Надіслати'}
              </button>
            </div>
          </div>

          {/* History */}
          {ticket.statusHistory.length > 0 && (
            <div className="card">
              <h3 style={{ fontWeight: 700, marginBottom: 12 }}>Історія змін</h3>
              {ticket.statusHistory.map(h => (
                <div key={h.id} className="history-item">
                  <div className="history-dot" />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13 }}>
                      <StatusBadge status={h.oldStatus} label={h.oldStatusLabel} />
                      {' → '}
                      <StatusBadge status={h.newStatus} label={h.newStatusLabel} />
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4 }}>
                      {h.changedBy.name} · {formatDate(h.changedAt)}
                      {h.note && <span> · "{h.note}"</span>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="ticket-sidebar-panel">
          <div className="card">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="ticket-meta-item">
                <div className="ticket-meta-label">Статус</div>
                <StatusBadge status={ticket.status} label={ticket.statusLabel} />
              </div>
              <div className="ticket-meta-item">
                <div className="ticket-meta-label">Пріоритет</div>
                <PriorityBadge priority={ticket.priority} label={ticket.priorityLabel} />
              </div>
              <div className="ticket-meta-item">
                <div className="ticket-meta-label">Категорія</div>
                <div className="ticket-meta-value">
                  <span style={{ display: 'inline-block', width: 10, height: 10, borderRadius: '50%', background: ticket.category.color, marginRight: 6 }} />
                  {ticket.category.name}
                </div>
              </div>
              <div className="ticket-meta-item">
                <div className="ticket-meta-label">Автор</div>
                <div className="ticket-meta-value">{ticket.createdBy.name}</div>
              </div>
              <div className="ticket-meta-item">
                <div className="ticket-meta-label">Термін виконання (SLA)</div>
                <div className="ticket-meta-value" style={{ fontSize: 13, color: ticket.isOverdue ? '#f87171' : undefined, fontWeight: ticket.isOverdue ? 700 : undefined }}>
                  {ticket.dueAt ? formatDate(ticket.dueAt) : '—'}
                </div>
              </div>
              {isAgent && (
                <div className="ticket-meta-item">
                  <div className="ticket-meta-label">Виконавець</div>
                  <select className="form-control" value={ticket.assignedTo?.id ?? ''} onChange={e => assignAgent(e.target.value || null)}>
                    <option value="">Не призначено</option>
                    {agents.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                  </select>
                </div>
              )}
              <div className="ticket-meta-item">
                <div className="ticket-meta-label">Створено</div>
                <div className="ticket-meta-value" style={{ fontSize: 13 }}>{formatDate(ticket.createdAt)}</div>
              </div>
              <div className="ticket-meta-item">
                <div className="ticket-meta-label">Оновлено</div>
                <div className="ticket-meta-value" style={{ fontSize: 13 }}>{formatDate(ticket.updatedAt)}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {statusModal && (
        <Modal title="Змінити статус" onClose={() => setStatusModal(false)}
          footer={<>
            <button className="btn btn-secondary" onClick={() => setStatusModal(false)}>Скасувати</button>
            <button className="btn btn-primary" onClick={changeStatus}>Зберегти</button>
          </>}>
          <div className="form-group">
            <label className="form-label">Новий статус</label>
            <select className="form-control" value={statusForm.newStatus} onChange={e => setStatusForm(f => ({ ...f, newStatus: parseInt(e.target.value) }))}>
              {STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Коментар (необов'язково)</label>
            <textarea className="form-control" rows={3} value={statusForm.note} onChange={e => setStatusForm(f => ({ ...f, note: e.target.value }))} />
          </div>
        </Modal>
      )}
    </div>
  )
}
