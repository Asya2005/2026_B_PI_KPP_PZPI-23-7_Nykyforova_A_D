import { NavLink, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const icons = {
  tickets: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>,
  plus: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14"/></svg>,
  stats: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 3v18h18"/><path d="M18 17V9M12 17V5M6 17v-3"/></svg>,
  users: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>,
  categories: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z"/></svg>,
  logout: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>,
  logo: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
}

const pageTitles = {
  '/tickets': 'Заявки',
  '/tickets/new': 'Нова заявка',
  '/stats': 'Статистика',
  '/users': 'Користувачі',
  '/categories': 'Категорії',
}

export default function Layout({ children }) {
  const { user, logout, isAdmin, isAgent } = useAuth()
  const location = useLocation()
  const title = Object.entries(pageTitles).find(([k]) =>
    k === location.pathname || location.pathname.startsWith(k + '/')
  )?.[1] ?? 'Service Desk'

  const initials = user?.name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() ?? '?'
  const roleLabel = { 0: 'Користувач', 1: 'Агент', 2: 'Адміністратор', User: 'Користувач', Agent: 'Агент', Admin: 'Адміністратор' }[user?.role] ?? ''

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="sidebar-logo">{icons.logo} Service Desk</div>
        <nav className="sidebar-nav">
          <NavLink to="/tickets" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
            {icons.tickets} Всі заявки
          </NavLink>
          <NavLink to="/tickets/new" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
            {icons.plus} Нова заявка
          </NavLink>
          {isAgent && (
            <NavLink to="/stats" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              {icons.stats} Статистика
            </NavLink>
          )}
          {isAdmin && (<>
            <NavLink to="/users" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              {icons.users} Користувачі
            </NavLink>
            <NavLink to="/categories" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              {icons.categories} Категорії
            </NavLink>
          </>)}
        </nav>
        <div className="sidebar-footer">
          <div className="sidebar-user">
            <div className="avatar">{initials}</div>
            <div className="sidebar-user-info">
              <div className="sidebar-user-name">{user?.name}</div>
              <div className="sidebar-user-role">{roleLabel}</div>
            </div>
          </div>
          <button className="logout-btn" onClick={logout}>{icons.logout} Вийти</button>
        </div>
      </aside>
      <div className="main">
        <div className="topbar"><div className="topbar-title">{title}</div></div>
        <div className="page-content">{children}</div>
      </div>
    </div>
  )
}
