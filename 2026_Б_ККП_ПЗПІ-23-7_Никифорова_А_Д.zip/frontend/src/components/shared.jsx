// Status & Priority badges
const STATUS_CLASS = {
  0: 'badge-new', New: 'badge-new',
  1: 'badge-inprogress', InProgress: 'badge-inprogress',
  2: 'badge-waiting', WaitingForReply: 'badge-waiting',
  3: 'badge-resolved', Resolved: 'badge-resolved',
  4: 'badge-closed', Closed: 'badge-closed',
  5: 'badge-rejected', Rejected: 'badge-rejected',
}
const PRIORITY_CLASS = {
  0: 'badge-low', Low: 'badge-low',
  1: 'badge-medium', Medium: 'badge-medium',
  2: 'badge-high', High: 'badge-high',
  3: 'badge-critical', Critical: 'badge-critical',
}

export function StatusBadge({ status, label }) {
  return <span className={`badge ${STATUS_CLASS[status] ?? 'badge-new'}`}>{label}</span>
}

export function PriorityBadge({ priority, label }) {
  return <span className={`badge ${PRIORITY_CLASS[priority] ?? 'badge-medium'}`}>{label}</span>
}

export function OverdueBadge() {
  return <span className="badge badge-overdue" title="Термін виконання за SLA минув">⏰ Прострочено</span>
}

export function Spinner() { return <div className="spinner" /> }

export function Modal({ title, onClose, children, footer }) {
  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <h2 className="modal-title">{title}</h2>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        {children}
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  )
}

export function Pagination({ page, totalPages, onChange }) {
  if (totalPages <= 1) return null
  const pages = Array.from({ length: Math.min(totalPages, 7) }, (_, i) => i + 1)
  return (
    <div className="pagination">
      <button className="page-btn" disabled={page === 1} onClick={() => onChange(page - 1)}>‹</button>
      {pages.map(p => (
        <button key={p} className={`page-btn ${p === page ? 'active' : ''}`} onClick={() => onChange(p)}>{p}</button>
      ))}
      <button className="page-btn" disabled={page === totalPages} onClick={() => onChange(page + 1)}>›</button>
    </div>
  )
}

export function formatDate(d) {
  if (!d) return '—'
  return new Date(d).toLocaleString('uk-UA', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

export function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} Б`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} КБ`
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`
}
