namespace ServiceDesk.Domain.Enums;

public enum TicketStatus
{
    New = 0,
    InProgress = 1,
    WaitingForReply = 2,
    Resolved = 3,
    Closed = 4,
    Rejected = 5
}

public enum TicketPriority
{
    Low = 0,
    Medium = 1,
    High = 2,
    Critical = 3
}

public enum UserRole
{
    User = 0,
    Agent = 1,
    Admin = 2
}
