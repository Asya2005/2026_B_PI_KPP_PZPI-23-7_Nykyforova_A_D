using ServiceDesk.Domain.Enums;

namespace ServiceDesk.Domain.Sla;

/// <summary>
/// Політика SLA: скільки часу дається на виконання заявки залежно від пріоритету.
/// </summary>
public static class SlaPolicy
{
    public static readonly IReadOnlyDictionary<TicketPriority, TimeSpan> ResolutionTime =
        new Dictionary<TicketPriority, TimeSpan>
        {
            [TicketPriority.Critical] = TimeSpan.FromHours(4),
            [TicketPriority.High] = TimeSpan.FromHours(8),
            [TicketPriority.Medium] = TimeSpan.FromHours(24),
            [TicketPriority.Low] = TimeSpan.FromHours(72),
        };

    public static DateTime CalculateDueAt(DateTime createdAt, TicketPriority priority) =>
        createdAt + ResolutionTime[priority];
}
