using Microsoft.EntityFrameworkCore;
using ServiceDesk.Application.Services;
using ServiceDesk.Domain.Entities;
using ServiceDesk.Domain.Enums;

namespace ServiceDesk.Infrastructure.Data;

public class AppDbContext : DbContext, IAppDbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Ticket> Tickets => Set<Ticket>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Comment> Comments => Set<Comment>();
    public DbSet<TicketStatusHistory> StatusHistory => Set<TicketStatusHistory>();
    public DbSet<Attachment> Attachments => Set<Attachment>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        // pg_trgm — потрібне для GIN-індексів під швидкий пошук по підрядку (ILIKE '%...%').
        mb.HasPostgresExtension("pg_trgm");

        // User
        mb.Entity<User>(e =>
        {
            e.HasIndex(u => u.Email).IsUnique();
            e.Property(u => u.Role).HasConversion<string>();
        });

        // Ticket
        mb.Entity<Ticket>(e =>
        {
            e.Property(t => t.Status).HasConversion<string>();
            e.Property(t => t.Priority).HasConversion<string>();
            e.HasIndex(t => t.Status);
            e.HasIndex(t => t.Priority);
            e.HasIndex(t => t.CreatedAt);
            e.HasIndex(t => t.AssignedToId);
            e.HasIndex(t => t.DueAt);

            // Композитні індекси під найчастіші комбінації фільтрів/сортувань списку заявок.
            e.HasIndex(t => new { t.Status, t.CreatedAt });
            e.HasIndex(t => new { t.CategoryId, t.Status });

            // Трайграм-індекси для швидкого пошуку по Title/Description (ILIKE '%текст%'),
            // який звичайний B-tree індекс прискорити не може.
            e.HasIndex(t => t.Title).HasMethod("gin").HasOperators("gin_trgm_ops");
            e.HasIndex(t => t.Description).HasMethod("gin").HasOperators("gin_trgm_ops");

            e.HasOne(t => t.CreatedBy)
                .WithMany(u => u.CreatedTickets)
                .HasForeignKey(t => t.CreatedById)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasOne(t => t.AssignedTo)
                .WithMany(u => u.AssignedTickets)
                .HasForeignKey(t => t.AssignedToId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        // StatusHistory
        mb.Entity<TicketStatusHistory>(e =>
        {
            e.Property(h => h.OldStatus).HasConversion<string>();
            e.Property(h => h.NewStatus).HasConversion<string>();
            e.HasOne(h => h.ChangedBy)
                .WithMany()
                .HasForeignKey(h => h.ChangedById)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Attachment
        mb.Entity<Attachment>(e =>
        {
            e.HasIndex(a => a.TicketId);

            e.HasOne(a => a.Ticket)
                .WithMany(t => t.Attachments)
                .HasForeignKey(a => a.TicketId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(a => a.UploadedBy)
                .WithMany()
                .HasForeignKey(a => a.UploadedById)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Seed data
        mb.Entity<User>().HasData(
    new User
    {
        Id = 1,
        Name = "Адміністратор",
        Email = "admin@servicedesk.ua",
        PasswordHash = "$2a$11$GZ.Aw2FKqy8B.H/t2UrOeeHOgGHy022YMi9Zzp6kqlA53WR.66Mv.",
        Role = UserRole.Admin,
        CreatedAt = new DateTime(2025, 1, 1, 0, 0, 0, DateTimeKind.Utc),
        IsActive = true
    },
    new User
    {
        Id = 2,
        Name = "Агент Іванов",
        Email = "agent@servicedesk.ua",
        PasswordHash = "$2a$11$i669fv7wq6W6D56J6GYmFegAyERwQhokyo2InRIB0oEEnkHqMF6vW",
        Role = UserRole.Agent,
        CreatedAt = new DateTime(2025, 1, 1, 0, 0, 0, DateTimeKind.Utc),
        IsActive = true
    },
    new User
    {
        Id = 3,
        Name = "Тестовий Користувач",
        Email = "user@servicedesk.ua",
        PasswordHash = "$2a$11$AUrXgAUz1rMpWVETxBcevezumLQ/3983eJgnD98xvwHqB5jJQ2WcO",
        Role = UserRole.User,
        CreatedAt = new DateTime(2025, 1, 1, 0, 0, 0, DateTimeKind.Utc),
        IsActive = true
    }
);

        mb.Entity<Category>().HasData(
            new Category { Id = 1, Name = "Технічна підтримка", Description = "Проблеми з обладнанням та ПЗ", Color = "#6366f1" },
            new Category { Id = 2, Name = "Мережа та інтернет", Description = "Проблеми з підключенням", Color = "#0ea5e9" },
            new Category { Id = 3, Name = "Облікові записи", Description = "Доступ та паролі", Color = "#10b981" },
            new Category { Id = 4, Name = "Інше", Description = "Загальні питання", Color = "#f59e0b" }
        );
    }
}
