using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceDesk.Application.DTOs;
using ServiceDesk.Application.Exceptions;
using ServiceDesk.Application.Interfaces;

namespace ServiceDesk.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController(IAuthService auth) : ControllerBase
{
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginDto dto)
    {
        try { return Ok(await auth.LoginAsync(dto)); }
        catch (UnauthorizedAccessException ex) { return Unauthorized(new { message = ex.Message }); }
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterDto dto)
    {
        try { return Ok(await auth.RegisterAsync(dto)); }
        catch (InvalidOperationException ex) { return BadRequest(new { message = ex.Message }); }
    }
}

// ── Tickets ───────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class TicketsController(ITicketService tickets) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private string UserRole => User.FindFirstValue(ClaimTypes.Role) ?? "User";

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] TicketFilterParams filter) =>
        Ok(await tickets.GetAllAsync(filter, UserId, UserRole));

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        try
        {
            var t = await tickets.GetByIdAsync(id, UserId, UserRole);
            return t == null ? NotFound() : Ok(t);
        }
        catch (ForbiddenAccessException) { return Forbid(); }
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateTicketDto dto)
    {
        var t = await tickets.CreateAsync(dto, UserId);
        return CreatedAtAction(nameof(GetById), new { id = t.Id }, t);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, UpdateTicketDto dto)
    {
        try
        {
            var t = await tickets.UpdateAsync(id, dto, UserId, UserRole);
            return t == null ? NotFound() : Ok(t);
        }
        catch (ForbiddenAccessException) { return Forbid(); }
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id) =>
        await tickets.DeleteAsync(id, UserRole) ? NoContent() : NotFound();

    [HttpPatch("{id}/status")]
    [Authorize(Roles = "Agent,Admin")]
    public async Task<IActionResult> ChangeStatus(int id, ChangeStatusDto dto)
    {
        try
        {
            var t = await tickets.ChangeStatusAsync(id, dto, UserId, UserRole);
            return t == null ? NotFound() : Ok(t);
        }
        catch (ForbiddenAccessException) { return Forbid(); }
    }

    [HttpPatch("{id}/assign")]
    [Authorize(Roles = "Agent,Admin")]
    public async Task<IActionResult> Assign(int id, AssignTicketDto dto)
    {
        try
        {
            var t = await tickets.AssignAsync(id, dto, UserRole);
            return t == null ? NotFound() : Ok(t);
        }
        catch (ForbiddenAccessException) { return Forbid(); }
        catch (InvalidOperationException ex) { return BadRequest(new { message = ex.Message }); }
    }
}

// ── Categories ────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class CategoriesController(ICategoryService cats) : ControllerBase
{
    [HttpGet] public async Task<IActionResult> GetAll() => Ok(await cats.GetAllAsync());
    [HttpGet("{id}")] public async Task<IActionResult> GetById(int id)
    {
        var c = await cats.GetByIdAsync(id);
        return c == null ? NotFound() : Ok(c);
    }
    [HttpPost][Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create(CreateCategoryDto dto) => Ok(await cats.CreateAsync(dto));
    [HttpPut("{id}")][Authorize(Roles = "Admin")]
    public async Task<IActionResult> Update(int id, UpdateCategoryDto dto)
    {
        var c = await cats.UpdateAsync(id, dto);
        return c == null ? NotFound() : Ok(c);
    }
    [HttpDelete("{id}")][Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id) =>
        await cats.DeleteAsync(id) ? NoContent() : NotFound();
}

// ── Users ─────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class UsersController(IUserService users) : ControllerBase
{
    [HttpGet][Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetAll() => Ok(await users.GetAllAsync());
    [HttpGet("agents")]
    public async Task<IActionResult> GetAgents() => Ok(await users.GetAgentsAsync());
    [HttpGet("{id}")][Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetById(int id)
    {
        var u = await users.GetByIdAsync(id);
        return u == null ? NotFound() : Ok(u);
    }
    [HttpPut("{id}")][Authorize(Roles = "Admin")]
    public async Task<IActionResult> Update(int id, UserUpdateDto dto)
    {
        var u = await users.UpdateAsync(id, dto);
        return u == null ? NotFound() : Ok(u);
    }
    [HttpDelete("{id}")][Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id) =>
        await users.DeleteAsync(id) ? NoContent() : NotFound();
}

// ── Comments ──────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/tickets/{ticketId}/comments")]
[Authorize]
public class CommentsController(ICommentService comments) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private string UserRole => User.FindFirstValue(ClaimTypes.Role) ?? "User";

    [HttpPost]
    public async Task<IActionResult> Add(int ticketId, CreateCommentDto dto) =>
        Ok(await comments.AddAsync(ticketId, dto, UserId));

    [HttpDelete("{commentId}")]
    public async Task<IActionResult> Delete(int ticketId, int commentId)
    {
        try
        {
            return await comments.DeleteAsync(commentId, UserId, UserRole) ? NoContent() : NotFound();
        }
        catch (ForbiddenAccessException) { return Forbid(); }
    }
}

// ── Stats ─────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Agent,Admin")]
public class StatsController(IStatsService stats) : ControllerBase
{
    [HttpGet] public async Task<IActionResult> Get() => Ok(await stats.GetStatsAsync());
}

// ── Attachments ───────────────────────────────────────────────────────────────
[ApiController]
[Route("api/tickets/{ticketId}/attachments")]
[Authorize]
public class AttachmentsController(IAttachmentService attachments) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private string UserRole => User.FindFirstValue(ClaimTypes.Role) ?? "User";

    [HttpPost]
    [RequestSizeLimit(10_500_000)]
    public async Task<IActionResult> Upload(int ticketId, IFormFile? file)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new { message = "Файл не передано" });

        try
        {
            await using var stream = file.OpenReadStream();
            var request = new UploadAttachmentRequest(file.FileName, file.ContentType, stream, file.Length);
            var dto = await attachments.UploadAsync(ticketId, request, UserId);
            return Ok(dto);
        }
        catch (KeyNotFoundException ex) { return NotFound(new { message = ex.Message }); }
        catch (InvalidOperationException ex) { return BadRequest(new { message = ex.Message }); }
    }

    [HttpGet("{id}/download")]
    public async Task<IActionResult> Download(int ticketId, int id)
    {
        try
        {
            var result = await attachments.DownloadAsync(ticketId, id, UserId, UserRole);
            return result == null ? NotFound() : File(result.Content, result.ContentType, result.FileName);
        }
        catch (ForbiddenAccessException) { return Forbid(); }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int ticketId, int id)
    {
        try
        {
            return await attachments.DeleteAsync(ticketId, id, UserId, UserRole) ? NoContent() : NotFound();
        }
        catch (ForbiddenAccessException) { return Forbid(); }
    }
}
