using ServiceDesk.Application.DTOs;
using ServiceDesk.Application.Services;
using Xunit;

namespace ServiceDesk.Tests;

public class CategoryServiceTests
{
    private static CategoryService MakeSut(out ServiceDesk.Infrastructure.Data.AppDbContext db)
    {
        db = TestDb.Create();
        return new CategoryService(db, TestDb.CreateCache());
    }

    [Fact]
    public async Task CreateAsync_HappyPath_AddsCategoryToDb()
    {
        var sut = MakeSut(out var db);
        var dto = new CreateCategoryDto("Бухгалтерія", "Питання з обліком", "#123456");

        var result = await sut.CreateAsync(dto);

        Assert.True(result.Id > 0);
        Assert.Equal("Бухгалтерія", result.Name);
        Assert.True(result.IsActive);
        Assert.Single(db.Categories);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsNull_WhenCategoryDoesNotExist()
    {
        var sut = MakeSut(out _);

        var result = await sut.GetByIdAsync(999);

        Assert.Null(result);
    }

    [Fact]
    public async Task UpdateAsync_HappyPath_UpdatesFields()
    {
        var sut = MakeSut(out var db);
        db.Categories.Add(TestData.MakeCategory(1, "Стара назва"));
        await db.SaveChangesAsync();

        var result = await sut.UpdateAsync(1, new UpdateCategoryDto("Нова назва", "новий опис", "#abcdef", false));

        Assert.NotNull(result);
        Assert.Equal("Нова назва", result!.Name);
        Assert.False(result.IsActive);
    }

    [Fact]
    public async Task UpdateAsync_ReturnsNull_WhenCategoryDoesNotExist()
    {
        var sut = MakeSut(out _);

        var result = await sut.UpdateAsync(999, new UpdateCategoryDto("X", "Y", "#000000", true));

        Assert.Null(result);
    }

    [Fact]
    public async Task DeleteAsync_HappyPath_RemovesCategory()
    {
        var sut = MakeSut(out var db);
        db.Categories.Add(TestData.MakeCategory(1));
        await db.SaveChangesAsync();

        var result = await sut.DeleteAsync(1);

        Assert.True(result);
        Assert.Empty(db.Categories);
    }

    [Fact]
    public async Task DeleteAsync_ReturnsFalse_WhenCategoryDoesNotExist()
    {
        var sut = MakeSut(out _);

        var result = await sut.DeleteAsync(999);

        Assert.False(result);
    }

    [Fact]
    public async Task GetAllAsync_ReturnsCachedResult_WithoutHittingDbTwice()
    {
        // Едж-кейс на кешування: після першого виклику категорію видаляють напряму
        // з БД (в обхід сервісу) — GetAllAsync досі має повертати закешований результат,
        // бо кеш живе 10 хв і не інвалідується сторонніми змінами.
        var db = TestDb.Create();
        var cache = TestDb.CreateCache();
        var sut = new CategoryService(db, cache);
        db.Categories.Add(TestData.MakeCategory(1, "Кешована"));
        await db.SaveChangesAsync();

        var first = await sut.GetAllAsync();

        db.Categories.RemoveRange(db.Categories);
        await db.SaveChangesAsync();

        var second = await sut.GetAllAsync();

        Assert.Single(first);
        Assert.Single(second); // з кешу, а не з (вже порожньої) БД
    }
}
