using ServiceDesk.Application.DTOs;
using ServiceDesk.Application.Exceptions;
using ServiceDesk.Application.Services;
using ServiceDesk.Domain.Enums;
using ServiceDesk.Domain.Sla;
using Xunit;

namespace ServiceDesk.Tests;

public class TicketServiceTests
{
    private static async Task<(TicketService sut, ServiceDesk.Infrastructure.Data.AppDbContext db)> MakeSutWithSeed()
    {
        var db = TestDb.Create();
        db.Users.Add(TestData.MakeUser(1, "user@example.com"));
        db.Users.Add(TestData.MakeUser(2, "otheruser@example.com"));
        db.Users.Add(TestData.MakeUser(3, "agent@example.com", UserRole.Agent));
        db.Categories.Add(TestData.MakeCategory(1));
        await db.SaveChangesAsync();
        return (new TicketService(db), db);
    }

    [Fact]
    public async Task CreateAsync_HappyPath_SetsDueAtAccordingToSlaPolicy()
    {
        var (sut, _) = await MakeSutWithSeed();
        var dto = new CreateTicketDto("Не працює принтер", "Опис проблеми", TicketPriority.High, CategoryId: 1);

        var before = DateTime.UtcNow;
        var result = await sut.CreateAsync(dto, userId: 1);
        var after = DateTime.UtcNow;

        Assert.Equal(TicketStatus.New, result.Status);
        Assert.NotNull(result.DueAt);
        // High-пріоритет: 8 годин на вирішення (SlaPolicy) від моменту створення.
        Assert.InRange(result.DueAt!.Value, before.Add(SlaPolicy.ResolutionTime[TicketPriority.High]),
            after.Add(SlaPolicy.ResolutionTime[TicketPriority.High]));
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsNull_WhenTicketDoesNotExist()
    {
        var (sut, _) = await MakeSutWithSeed();

        var result = await sut.GetByIdAsync(999);

        Assert.Null(result);
    }

    [Fact]
    public async Task GetAllAsync_RegularUser_SeesOnlyOwnTickets()
    {
        // Бізнес-правило: звичайний User бачить лише свої заявки, на відміну від агента/адміна.
        var (sut, db) = await MakeSutWithSeed();
        db.Tickets.Add(TestData.MakeTicket(1, createdById: 1, categoryId: 1));
        db.Tickets.Add(TestData.MakeTicket(2, createdById: 2, categoryId: 1));
        await db.SaveChangesAsync();

        var result = await sut.GetAllAsync(new TicketFilterParams(), userId: 1, role: "User");

        Assert.Single(result.Items);
        Assert.Equal(1, result.Items[0].Id);
    }

    [Fact]
    public async Task GetAllAsync_Agent_SeesAllTickets()
    {
        var (sut, db) = await MakeSutWithSeed();
        db.Tickets.Add(TestData.MakeTicket(1, createdById: 1, categoryId: 1));
        db.Tickets.Add(TestData.MakeTicket(2, createdById: 2, categoryId: 1));
        await db.SaveChangesAsync();

        var result = await sut.GetAllAsync(new TicketFilterParams(), userId: 3, role: "Agent");

        Assert.Equal(2, result.Items.Count);
    }

    [Fact]
    public async Task UpdateAsync_Throws_WhenUserTriesToEditSomeoneElsesTicket()
    {
        var (sut, db) = await MakeSutWithSeed();
        db.Tickets.Add(TestData.MakeTicket(1, createdById: 2, categoryId: 1)); // належить іншому користувачу
        await db.SaveChangesAsync();
        var dto = new UpdateTicketDto("Нова назва", "новий опис", TicketPriority.Low, 1);

        await Assert.ThrowsAsync<ForbiddenAccessException>(
            () => sut.UpdateAsync(1, dto, userId: 1, userRole: "User"));
    }

    [Fact]
    public async Task UpdateAsync_HappyPath_RecalculatesDueAt_WhenPriorityChanges()
    {
        var (sut, db) = await MakeSutWithSeed();
        var createdAt = DateTime.UtcNow.AddHours(-1);
        var ticket = TestData.MakeTicket(1, createdById: 1, categoryId: 1, priority: TicketPriority.Low);
        ticket.CreatedAt = createdAt;
        ticket.DueAt = SlaPolicy.CalculateDueAt(createdAt, TicketPriority.Low);
        db.Tickets.Add(ticket);
        await db.SaveChangesAsync();

        var dto = new UpdateTicketDto(ticket.Title, ticket.Description, TicketPriority.Critical, 1);
        var result = await sut.UpdateAsync(1, dto, userId: 1, userRole: "User");

        Assert.NotNull(result);
        Assert.Equal(SlaPolicy.CalculateDueAt(createdAt, TicketPriority.Critical), result!.DueAt);
    }

    [Fact]
    public async Task DeleteAsync_ReturnsFalse_WhenUserIsNotAdmin()
    {
        var (sut, db) = await MakeSutWithSeed();
        db.Tickets.Add(TestData.MakeTicket(1, createdById: 1, categoryId: 1));
        await db.SaveChangesAsync();

        var result = await sut.DeleteAsync(1, userRole: "Agent");

        Assert.False(result);
        Assert.Single(db.Tickets); // заявку не видалено
    }

    [Fact]
    public async Task ChangeStatusAsync_Throws_WhenRegularUserTriesToChangeStatus()
    {
        var (sut, db) = await MakeSutWithSeed();
        db.Tickets.Add(TestData.MakeTicket(1, createdById: 1, categoryId: 1));
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<ForbiddenAccessException>(() => sut.ChangeStatusAsync(
            1, new ChangeStatusDto(TicketStatus.InProgress, "beру в роботу"), userId: 1, userRole: "User"));
    }

    [Fact]
    public async Task ChangeStatusAsync_HappyPath_RecordsStatusHistory()
    {
        var (sut, db) = await MakeSutWithSeed();
        db.Tickets.Add(TestData.MakeTicket(1, createdById: 1, categoryId: 1));
        await db.SaveChangesAsync();

        var result = await sut.ChangeStatusAsync(
            1, new ChangeStatusDto(TicketStatus.InProgress, "беру в роботу"), userId: 3, userRole: "Agent");

        Assert.NotNull(result);
        Assert.Equal(TicketStatus.InProgress, result!.Status);
        Assert.Single(db.StatusHistory);
        Assert.Equal(TicketStatus.New, db.StatusHistory.First().OldStatus);
    }

    [Fact]
    public async Task AssignAsync_Throws_WhenAssignedUserIsNotAgentOrAdmin()
    {
        // Едж-кейс: не можна призначити виконавцем звичайного User (валідація ролі).
        var (sut, db) = await MakeSutWithSeed();
        db.Tickets.Add(TestData.MakeTicket(1, createdById: 1, categoryId: 1));
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<InvalidOperationException>(
            () => sut.AssignAsync(1, new AssignTicketDto(AgentId: 1), userRole: "Admin"));
    }

    [Fact]
    public async Task AssignAsync_HappyPath_AssignsValidAgent()
    {
        var (sut, db) = await MakeSutWithSeed();
        db.Tickets.Add(TestData.MakeTicket(1, createdById: 1, categoryId: 1));
        await db.SaveChangesAsync();

        var result = await sut.AssignAsync(1, new AssignTicketDto(AgentId: 3), userRole: "Admin");

        Assert.NotNull(result);
        Assert.Equal(3, result!.AssignedTo!.Id);
    }
}
