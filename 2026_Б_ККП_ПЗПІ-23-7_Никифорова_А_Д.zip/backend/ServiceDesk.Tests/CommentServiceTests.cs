using ServiceDesk.Application.DTOs;
using ServiceDesk.Application.Exceptions;
using ServiceDesk.Application.Services;
using ServiceDesk.Domain.Enums;
using Xunit;

namespace ServiceDesk.Tests;

public class CommentServiceTests
{
    private static async Task<(CommentService sut, ServiceDesk.Infrastructure.Data.AppDbContext db)> MakeSutWithTicket()
    {
        var db = TestDb.Create();
        db.Users.Add(TestData.MakeUser(1, "author@example.com"));
        db.Users.Add(TestData.MakeUser(2, "other@example.com"));
        db.Users.Add(TestData.MakeUser(3, "admin@example.com", UserRole.Admin));
        db.Categories.Add(TestData.MakeCategory(1));
        db.Tickets.Add(TestData.MakeTicket(1, createdById: 1, categoryId: 1));
        await db.SaveChangesAsync();
        return (new CommentService(db), db);
    }

    [Fact]
    public async Task AddAsync_HappyPath_CreatesComment()
    {
        var (sut, db) = await MakeSutWithTicket();

        var result = await sut.AddAsync(1, new CreateCommentDto("Тестовий коментар"), userId: 1);

        Assert.Equal("Тестовий коментар", result.Text);
        Assert.Equal(1, result.User.Id);
        Assert.Single(db.Comments);
    }

    [Fact]
    public async Task DeleteAsync_HappyPath_OwnerCanDeleteOwnComment()
    {
        var (sut, db) = await MakeSutWithTicket();
        var comment = await sut.AddAsync(1, new CreateCommentDto("Мій коментар"), userId: 1);

        var result = await sut.DeleteAsync(comment.Id, userId: 1, userRole: "User");

        Assert.True(result);
        Assert.Empty(db.Comments);
    }

    [Fact]
    public async Task DeleteAsync_Throws_WhenNonOwnerNonAdminTriesToDelete()
    {
        var (sut, _) = await MakeSutWithTicket();
        var comment = await sut.AddAsync(1, new CreateCommentDto("Чужий коментар"), userId: 1);

        await Assert.ThrowsAsync<ForbiddenAccessException>(
            () => sut.DeleteAsync(comment.Id, userId: 2, userRole: "User"));
    }

    [Fact]
    public async Task DeleteAsync_HappyPath_AdminCanDeleteAnyComment()
    {
        // Едж-кейс: адміністратор не є автором коментаря, але має право його видалити.
        var (sut, db) = await MakeSutWithTicket();
        var comment = await sut.AddAsync(1, new CreateCommentDto("Коментар користувача"), userId: 1);

        var result = await sut.DeleteAsync(comment.Id, userId: 3, userRole: "Admin");

        Assert.True(result);
        Assert.Empty(db.Comments);
    }

    [Fact]
    public async Task DeleteAsync_ReturnsFalse_WhenCommentDoesNotExist()
    {
        var (sut, _) = await MakeSutWithTicket();

        var result = await sut.DeleteAsync(999, userId: 1, userRole: "User");

        Assert.False(result);
    }
}
