using ServiceDesk.Application.DTOs;
using ServiceDesk.Application.Services;
using ServiceDesk.Domain.Enums;
using Xunit;

namespace ServiceDesk.Tests;

public class AuthServiceTests
{
    private static AuthService MakeSut(out ServiceDesk.Infrastructure.Data.AppDbContext db)
    {
        db = TestDb.Create();
        return new AuthService(db, TestDb.CreateConfig());
    }

    [Fact]
    public async Task RegisterAsync_HappyPath_CreatesUserAndReturnsToken()
    {
        var sut = MakeSut(out var db);
        var dto = new RegisterDto("Нова Людина", "new.user@example.com", "Password123!");

        var result = await sut.RegisterAsync(dto);

        Assert.NotNull(result.Token);
        Assert.NotEmpty(result.Token);
        Assert.Equal(dto.Email, result.User.Email);
        Assert.Equal(dto.Name, result.User.Name);
        Assert.Equal(UserRole.User, result.User.Role); // нові користувачі завжди отримують роль User
        Assert.Single(db.Users);
    }

    [Fact]
    public async Task RegisterAsync_Throws_WhenEmailAlreadyUsed()
    {
        var sut = MakeSut(out var db);
        db.Users.Add(TestData.MakeUser(1, "taken@example.com"));
        await db.SaveChangesAsync();

        var dto = new RegisterDto("Хтось", "taken@example.com", "Password123!");

        await Assert.ThrowsAsync<InvalidOperationException>(() => sut.RegisterAsync(dto));
    }

    [Fact]
    public async Task LoginAsync_HappyPath_ReturnsTokenForValidCredentials()
    {
        var sut = MakeSut(out var db);
        db.Users.Add(TestData.MakeUser(1, "valid@example.com"));
        await db.SaveChangesAsync();

        var result = await sut.LoginAsync(new LoginDto("valid@example.com", "Password123!"));

        Assert.NotNull(result.Token);
        Assert.Equal("valid@example.com", result.User.Email);
    }

    [Fact]
    public async Task LoginAsync_Throws_WhenPasswordIsWrong()
    {
        var sut = MakeSut(out var db);
        db.Users.Add(TestData.MakeUser(1, "valid@example.com"));
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<UnauthorizedAccessException>(
            () => sut.LoginAsync(new LoginDto("valid@example.com", "WrongPassword!")));
    }

    [Fact]
    public async Task LoginAsync_Throws_WhenUserDoesNotExist()
    {
        var sut = MakeSut(out _);

        await Assert.ThrowsAsync<UnauthorizedAccessException>(
            () => sut.LoginAsync(new LoginDto("ghost@example.com", "Password123!")));
    }

    [Fact]
    public async Task LoginAsync_Throws_WhenUserIsDeactivated()
    {
        // Едж-кейс: користувача деактивували (IsActive = false) — логін має падати
        // так само, як для неіснуючого користувача, і не розкривати, що акаунт існує.
        var sut = MakeSut(out var db);
        db.Users.Add(TestData.MakeUser(1, "inactive@example.com", isActive: false));
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<UnauthorizedAccessException>(
            () => sut.LoginAsync(new LoginDto("inactive@example.com", "Password123!")));
    }
}
