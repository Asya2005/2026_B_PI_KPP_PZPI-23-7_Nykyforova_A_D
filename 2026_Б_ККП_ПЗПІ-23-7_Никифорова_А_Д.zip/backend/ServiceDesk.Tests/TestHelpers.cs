using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using ServiceDesk.Domain.Entities;
using ServiceDesk.Domain.Enums;
using ServiceDesk.Infrastructure.Data;

namespace ServiceDesk.Tests;

/// <summary>
/// Створює окрему in-memory базу для кожного тесту (унікальна назва через Guid),
/// тому тести повністю ізольовані один від одного та можуть виконуватись паралельно.
/// AppDbContext беремо справжній (не мок), щоб LINQ-запити з Include/Where/OrderBy
/// у сервісах виконувались так само, як і з реальною PostgreSQL.
/// </summary>
public static class TestDb
{
    public static AppDbContext Create()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        var ctx = new AppDbContext(options);
        // OnModelCreating сідить довідникових User/Category (Id 1-3, 1-4) через HasData —
        // це заважало б тестам мати контроль над початковим станом, тому кожен тест
        // сам додає потрібні йому сутності поверх чистої бази.
        return ctx;
    }

    public static IMemoryCache CreateCache() => new MemoryCache(new MemoryCacheOptions());

    public static IConfiguration CreateConfig() =>
        new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Jwt:Key"] = "test-signing-key-for-unit-tests-only-1234567890",
            ["Jwt:Issuer"] = "ServiceDesk.Tests",
            ["Jwt:Audience"] = "ServiceDesk.Tests",
        }).Build();
}

/// <summary>Фабрика тестових сутностей з розумними значеннями за замовчуванням.</summary>
public static class TestData
{
    public static User MakeUser(int id, string email, UserRole role = UserRole.User, bool isActive = true) => new()
    {
        Id = id,
        Name = $"User{id}",
        Email = email,
        PasswordHash = BCrypt.Net.BCrypt.HashPassword("Password123!"),
        Role = role,
        IsActive = isActive,
        CreatedAt = DateTime.UtcNow
    };

    public static Category MakeCategory(int id, string name = "Category") => new()
    {
        Id = id,
        Name = name,
        Description = "desc",
        Color = "#6366f1",
        IsActive = true
    };

    public static Ticket MakeTicket(int id, int createdById, int categoryId,
        TicketPriority priority = TicketPriority.Medium, TicketStatus status = TicketStatus.New) => new()
    {
        Id = id,
        Title = $"Ticket {id}",
        Description = "desc",
        Priority = priority,
        Status = status,
        CategoryId = categoryId,
        CreatedById = createdById,
        CreatedAt = DateTime.UtcNow,
        UpdatedAt = DateTime.UtcNow
    };
}
