using ServiceDesk.Domain.Enums;

namespace ServiceDesk.Application.DTOs;

// ── Auth ──────────────────────────────────────────────────────────────────────
public record LoginDto(string Email, string Password);
public record RegisterDto(string Name, string Email, string Password);
public record AuthResponseDto(string Token, UserDto User);

// ── User ──────────────────────────────────────────────────────────────────────
public record UserDto(int Id, string Name, string Email, UserRole Role, DateTime CreatedAt, bool IsActive);
public record UserUpdateDto(string Name, string Email, UserRole Role, bool IsActive);

// ── Category ──────────────────────────────────────────────────────────────────
public record CategoryDto(int Id, string Name, string Description, string Color, bool IsActive);
public record CreateCategoryDto(string Name, string Description, string Color);
public record UpdateCategoryDto(string Name, string Description, string Color, bool IsActive);

// ── Ticket ────────────────────────────────────────────────────────────────────
public record TicketDto(
    int Id,
    string Title,
    string Description,
    TicketStatus Status,
    string StatusLabel,
    TicketPriority Priority,
    string PriorityLabel,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    UserDto CreatedBy,
    UserDto? AssignedTo,
    CategoryDto Category,
    int CommentCount,
    DateTime? DueAt,
    bool IsOverdue
);

public record TicketDetailDto(
    int Id,
    string Title,
    string Description,
    TicketStatus Status,
    string StatusLabel,
    TicketPriority Priority,
    string PriorityLabel,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    UserDto CreatedBy,
    UserDto? AssignedTo,
    CategoryDto Category,
    List<CommentDto> Comments,
    List<StatusHistoryDto> StatusHistory,
    List<AttachmentDto> Attachments,
    DateTime? DueAt,
    bool IsOverdue
);

public record CreateTicketDto(string Title, string Description, TicketPriority Priority, int CategoryId);
public record UpdateTicketDto(string Title, string Description, TicketPriority Priority, int CategoryId);
public record ChangeStatusDto(TicketStatus NewStatus, string? Note);
public record AssignTicketDto(int? AgentId);

// ── Comment ───────────────────────────────────────────────────────────────────
public record CommentDto(int Id, string Text, DateTime CreatedAt, UserDto User);
public record CreateCommentDto(string Text);

// ── Attachment ────────────────────────────────────────────────────────────────
public record AttachmentDto(
    int Id,
    string FileName,
    string ContentType,
    long FileSizeBytes,
    DateTime UploadedAt,
    UserDto UploadedBy
);

// Вхідні дані для сервісу завантаження файлу; Stream, тому не record-DTO у
// звичному сенсі, але лишається в Application, щоб не тягнути залежність від
// ASP.NET Core (IFormFile) у бізнес-логіку.
public record UploadAttachmentRequest(string FileName, string? ContentType, Stream Content, long Length);

public record AttachmentDownload(Stream Content, string ContentType, string FileName);

// ── StatusHistory ─────────────────────────────────────────────────────────────
public record StatusHistoryDto(
    int Id,
    TicketStatus OldStatus,
    string OldStatusLabel,
    TicketStatus NewStatus,
    string NewStatusLabel,
    DateTime ChangedAt,
    string? Note,
    UserDto ChangedBy
);

// ── Pagination ────────────────────────────────────────────────────────────────
public record PagedResult<T>(List<T> Items, int TotalCount, int Page, int PageSize, int TotalPages);

public record TicketFilterParams(
    TicketStatus? Status = null,
    TicketPriority? Priority = null,
    int? CategoryId = null,
    int? AssignedToId = null,
    string? Search = null,
    string SortBy = "createdAt",
    bool SortDesc = true,
    int Page = 1,
    int PageSize = 10
);

// ── Stats ─────────────────────────────────────────────────────────────────────
public record StatsDto(
    int TotalTickets,
    int NewTickets,
    int InProgressTickets,
    int ResolvedTickets,
    int ClosedTickets,
    List<CategoryStatDto> ByCategory,
    List<AgentStatDto> ByAgent
);
public record CategoryStatDto(string Name, string Color, int Count);
public record AgentStatDto(string Name, int Assigned, int Resolved);
