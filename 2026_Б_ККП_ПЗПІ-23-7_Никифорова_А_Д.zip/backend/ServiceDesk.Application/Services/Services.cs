using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using ServiceDesk.Application.DTOs;
using ServiceDesk.Application.Exceptions;
using ServiceDesk.Application.Interfaces;
using ServiceDesk.Domain.Entities;
using ServiceDesk.Domain.Enums;
using ServiceDesk.Domain.Sla;
using BCrypt.Net;

namespace ServiceDesk.Application.Services;

// ── Helpers ───────────────────────────────────────────────────────────────────
public static class Mappers
{
    public static UserDto ToDto(this User u) => new(u.Id, u.Name, u.Email, u.Role, u.CreatedAt, u.IsActive);
    public static CategoryDto ToDto(this Category c) => new(c.Id, c.Name, c.Description, c.Color, c.IsActive);

    public static bool IsOverdue(Ticket t) =>
        t.DueAt.HasValue
        && t.Status != TicketStatus.Resolved
        && t.Status != TicketStatus.Closed
        && t.Status != TicketStatus.Rejected
        && t.DueAt.Value < DateTime.UtcNow;

    public static string StatusLabel(TicketStatus s) => s switch
    {
        TicketStatus.New => "Нова",
        TicketStatus.InProgress => "В роботі",
        TicketStatus.WaitingForReply => "Очікує відповіді",
        TicketStatus.Resolved => "Вирішена",
        TicketStatus.Closed => "Закрита",
        TicketStatus.Rejected => "Відхилена",
        _ => s.ToString()
    };

    public static string PriorityLabel(TicketPriority p) => p switch
    {
        TicketPriority.Low => "Низький",
        TicketPriority.Medium => "Середній",
        TicketPriority.High => "Високий",
        TicketPriority.Critical => "Критичний",
        _ => p.ToString()
    };

    // commentCount передається явно, щоб можна було рахувати коментарі
    // окремою підзапитом-агрегацією, не завантажуючи всю колекцію Comments.
    public static TicketDto ToDto(this Ticket t, int commentCount) => new(
        t.Id, t.Title, t.Description,
        t.Status, StatusLabel(t.Status),
        t.Priority, PriorityLabel(t.Priority),
        t.CreatedAt, t.UpdatedAt,
        t.CreatedBy.ToDto(), t.AssignedTo?.ToDto(),
        t.Category.ToDto(),
        commentCount,
        t.DueAt, IsOverdue(t)
    );

    // Зручний оверлоад для випадків, коли Comments вже завантажена (Include).
    public static TicketDto ToDto(this Ticket t) => t.ToDto(t.Comments.Count);

    public static CommentDto ToDto(this Comment c) => new(c.Id, c.Text, c.CreatedAt, c.User.ToDto());

    public static AttachmentDto ToDto(this Attachment a) => new(
        a.Id, a.FileName, a.ContentType, a.FileSizeBytes, a.UploadedAt, a.UploadedBy.ToDto());

    public static StatusHistoryDto ToDto(this TicketStatusHistory h) => new(
        h.Id, h.OldStatus, StatusLabel(h.OldStatus),
        h.NewStatus, StatusLabel(h.NewStatus),
        h.ChangedAt, h.Note, h.ChangedBy.ToDto()
    );
}

// ── IDbContext interface (implemented in Infrastructure) ──────────────────────
public interface IAppDbContext
{
    DbSet<User> Users { get; }
    DbSet<Ticket> Tickets { get; }
    DbSet<Category> Categories { get; }
    DbSet<Comment> Comments { get; }
    DbSet<TicketStatusHistory> StatusHistory { get; }
    DbSet<Attachment> Attachments { get; }
    Task<int> SaveChangesAsync(CancellationToken ct = default);
}

// ── TicketService ─────────────────────────────────────────────────────────────
public class TicketService(IAppDbContext db) : ITicketService
{
    // AsNoTracking: це виключно запити на читання, EF Core не повинен
    // витрачати ресурси на відстеження змін цих сутностей.
    // Comments свідомо НЕ Include'иться тут — кількість коментарів для списку
    // рахується окремою легкою підзапитом-агрегацією (див. GetAllAsync),
    // а не завантаженням усіх рядків Comments для кожної заявки.
    private IQueryable<Ticket> BaseQuery() => db.Tickets
        .AsNoTracking()
        .Include(t => t.CreatedBy)
        .Include(t => t.AssignedTo)
        .Include(t => t.Category);

    public async Task<PagedResult<TicketDto>> GetAllAsync(TicketFilterParams f, int userId, string role)
    {
        var q = BaseQuery().AsQueryable();

        if (f.Status.HasValue) q = q.Where(t => t.Status == f.Status.Value);
        if (f.Priority.HasValue) q = q.Where(t => t.Priority == f.Priority.Value);
        if (f.CategoryId.HasValue) q = q.Where(t => t.CategoryId == f.CategoryId.Value);
        if (f.AssignedToId.HasValue) q = q.Where(t => t.AssignedToId == f.AssignedToId.Value);
        if (!string.IsNullOrWhiteSpace(f.Search))
            q = q.Where(t => t.Title.Contains(f.Search) || t.Description.Contains(f.Search));

        // Regular users see only their tickets
        if (role == "User") q = q.Where(t => t.CreatedById == userId);

        q = (f.SortBy, f.SortDesc) switch
        {
            ("priority", true)  => q.OrderByDescending(t => t.Priority),
            ("priority", false) => q.OrderBy(t => t.Priority),
            ("status", true)    => q.OrderByDescending(t => t.Status),
            ("status", false)   => q.OrderBy(t => t.Status),
            ("title", true)     => q.OrderByDescending(t => t.Title),
            ("title", false)    => q.OrderBy(t => t.Title),
            (_, true)           => q.OrderByDescending(t => t.CreatedAt),
            _                   => q.OrderBy(t => t.CreatedAt),
        };

        var total = await q.CountAsync();

        // Кількість коментарів рахується в БД (COUNT-підзапит), а не через
        // завантаження всіх коментарів кожної заявки в пам'ять — головна
        // оптимізація списку заявок.
        var page = await q.Skip((f.Page - 1) * f.PageSize).Take(f.PageSize)
            .Select(t => new { Ticket = t, CommentCount = t.Comments.Count })
            .ToListAsync();
        var items = page.Select(x => x.Ticket.ToDto(x.CommentCount)).ToList();

        return new PagedResult<TicketDto>(items, total, f.Page, f.PageSize,
            (int)Math.Ceiling((double)total / f.PageSize));
    }

    // Перевіряє належність заявки поточному користувачеві перед тим, як віддати повні
    // дані (опис, коментарі, історію, вкладення) — той самий патерн IDOR-захисту, що й у
    // UpdateAsync/ChangeStatusAsync та у AttachmentService.DownloadAsync, застосований і тут,
    // адже без нього User-роль могла підставити довільний ticket id в URL і побачити чужу заявку.
    public async Task<TicketDetailDto?> GetByIdAsync(int id, int currentUserId, string currentUserRole)
    {
        var t = await db.Tickets.AsNoTracking().FirstOrDefaultAsync(t => t.Id == id);
        if (t == null) return null;
        if (currentUserRole == "User" && t.CreatedById != currentUserId)
            throw new ForbiddenAccessException("Ви можете переглядати лише власні заявки");
        return await GetByIdAsync(id);
    }

    public async Task<TicketDetailDto?> GetByIdAsync(int id)
    {
        var t = await db.Tickets
            .AsNoTracking()
            .Include(t => t.CreatedBy).Include(t => t.AssignedTo).Include(t => t.Category)
            .Include(t => t.Comments).ThenInclude(c => c.User)
            .Include(t => t.StatusHistory).ThenInclude(h => h.ChangedBy)
            .Include(t => t.Attachments).ThenInclude(a => a.UploadedBy)
            .FirstOrDefaultAsync(t => t.Id == id);
        if (t == null) return null;

        return new TicketDetailDto(
            t.Id, t.Title, t.Description,
            t.Status, Mappers.StatusLabel(t.Status),
            t.Priority, Mappers.PriorityLabel(t.Priority),
            t.CreatedAt, t.UpdatedAt,
            t.CreatedBy.ToDto(), t.AssignedTo?.ToDto(), t.Category.ToDto(),
            t.Comments.OrderBy(c => c.CreatedAt).Select(c => c.ToDto()).ToList(),
            t.StatusHistory.OrderBy(h => h.ChangedAt).Select(h => h.ToDto()).ToList(),
            t.Attachments.OrderBy(a => a.UploadedAt).Select(a => a.ToDto()).ToList(),
            t.DueAt, Mappers.IsOverdue(t)
        );
    }

    public async Task<TicketDto> CreateAsync(CreateTicketDto dto, int userId)
    {
        var now = DateTime.UtcNow;
        var ticket = new Ticket
        {
            Title = dto.Title,
            Description = dto.Description,
            Priority = dto.Priority,
            CategoryId = dto.CategoryId,
            CreatedById = userId,
            Status = TicketStatus.New,
            CreatedAt = now,
            UpdatedAt = now,
            DueAt = SlaPolicy.CalculateDueAt(now, dto.Priority)
        };
        db.Tickets.Add(ticket);
        await db.SaveChangesAsync();
        return (await GetByIdAsync(ticket.Id))!.ToTicketDto();
    }

    public async Task<TicketDto?> UpdateAsync(int id, UpdateTicketDto dto, int userId, string userRole)
    {
        var t = await db.Tickets.FindAsync(id);
        if (t == null) return null;
        if (userRole == "User" && t.CreatedById != userId)
            throw new ForbiddenAccessException("Ви можете редагувати лише власні заявки");

        // Якщо пріоритет змінився — перераховуємо термін SLA від початкової дати створення.
        if (t.Priority != dto.Priority)
            t.DueAt = SlaPolicy.CalculateDueAt(t.CreatedAt, dto.Priority);

        t.Title = dto.Title;
        t.Description = dto.Description;
        t.Priority = dto.Priority;
        t.CategoryId = dto.CategoryId;
        t.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return (await GetByIdAsync(id))!.ToTicketDto();
    }

    public async Task<bool> DeleteAsync(int id, string userRole)
    {
        if (userRole != "Admin") return false;
        var t = await db.Tickets.FindAsync(id);
        if (t == null) return false;
        db.Tickets.Remove(t);
        await db.SaveChangesAsync();
        return true;
    }

    public async Task<TicketDto?> ChangeStatusAsync(int id, ChangeStatusDto dto, int userId, string userRole)
    {
        var t = await db.Tickets.FindAsync(id);
        if (t == null) return null;
        if (userRole == "User")
            throw new ForbiddenAccessException("Лише агент або адміністратор може змінювати статус заявки");

        var history = new TicketStatusHistory
        {
            TicketId = id, OldStatus = t.Status, NewStatus = dto.NewStatus,
            ChangedById = userId, Note = dto.Note
        };
        db.StatusHistory.Add(history);
        t.Status = dto.NewStatus;
        t.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return (await GetByIdAsync(id))!.ToTicketDto();
    }

    public async Task<TicketDto?> AssignAsync(int id, AssignTicketDto dto, string userRole)
    {
        if (userRole == "User")
            throw new ForbiddenAccessException("Лише агент або адміністратор може призначати виконавця");

        var t = await db.Tickets.FindAsync(id);
        if (t == null) return null;

        if (dto.AgentId.HasValue)
        {
            var agent = await db.Users.FindAsync(dto.AgentId.Value);
            if (agent == null || (agent.Role != UserRole.Agent && agent.Role != UserRole.Admin))
                throw new InvalidOperationException("Вказаний користувач не є агентом або адміністратором");
        }

        t.AssignedToId = dto.AgentId;
        t.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return (await GetByIdAsync(id))!.ToTicketDto();
    }
}

// Extension to convert TicketDetailDto to TicketDto
public static class TicketDetailExtensions
{
    public static TicketDto ToTicketDto(this TicketDetailDto d) => new(
        d.Id, d.Title, d.Description, d.Status, d.StatusLabel,
        d.Priority, d.PriorityLabel, d.CreatedAt, d.UpdatedAt,
        d.CreatedBy, d.AssignedTo, d.Category, d.Comments.Count,
        d.DueAt, d.IsOverdue
    );
}

// ── CategoryService ───────────────────────────────────────────────────────────
// Категорії змінюються рідко, а читаються на кожному завантаженні списку заявок
// і форми створення — тому кешуємо повний список на короткий час і скидаємо
// кеш при будь-якій зміні.
public class CategoryService(IAppDbContext db, IMemoryCache cache) : ICategoryService
{
    private const string AllCacheKey = "categories:all";

    public async Task<List<CategoryDto>> GetAllAsync()
    {
        if (cache.TryGetValue(AllCacheKey, out List<CategoryDto>? cached) && cached != null)
            return cached;

        var categories = await db.Categories.AsNoTracking().Select(c => c.ToDto()).ToListAsync();
        cache.Set(AllCacheKey, categories, TimeSpan.FromMinutes(10));
        return categories;
    }

    public async Task<CategoryDto?> GetByIdAsync(int id) =>
        (await db.Categories.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id))?.ToDto();

    public async Task<CategoryDto> CreateAsync(CreateCategoryDto dto)
    {
        var c = new Category { Name = dto.Name, Description = dto.Description, Color = dto.Color };
        db.Categories.Add(c);
        await db.SaveChangesAsync();
        cache.Remove(AllCacheKey);
        return c.ToDto();
    }

    public async Task<CategoryDto?> UpdateAsync(int id, UpdateCategoryDto dto)
    {
        var c = await db.Categories.FindAsync(id);
        if (c == null) return null;
        c.Name = dto.Name; c.Description = dto.Description;
        c.Color = dto.Color; c.IsActive = dto.IsActive;
        await db.SaveChangesAsync();
        cache.Remove(AllCacheKey);
        return c.ToDto();
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var c = await db.Categories.FindAsync(id);
        if (c == null) return false;
        db.Categories.Remove(c);
        await db.SaveChangesAsync();
        cache.Remove(AllCacheKey);
        return true;
    }
}

// ── UserService ───────────────────────────────────────────────────────────────
public class UserService(IAppDbContext db, IMemoryCache cache) : IUserService
{
    // Список агентів запитується на кожній сторінці заявки (для селекта "Виконавець"),
    // а змінюється рідко — теж кандидат на кешування.
    private const string AgentsCacheKey = "users:agents";

    public async Task<List<UserDto>> GetAllAsync() =>
        await db.Users.AsNoTracking().Select(u => u.ToDto()).ToListAsync();

    public async Task<List<UserDto>> GetAgentsAsync()
    {
        if (cache.TryGetValue(AgentsCacheKey, out List<UserDto>? cached) && cached != null)
            return cached;

        var agents = await db.Users.AsNoTracking()
            .Where(u => u.Role == UserRole.Agent || u.Role == UserRole.Admin)
            .Select(u => u.ToDto()).ToListAsync();
        cache.Set(AgentsCacheKey, agents, TimeSpan.FromMinutes(10));
        return agents;
    }

    public async Task<UserDto?> GetByIdAsync(int id) =>
        (await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == id))?.ToDto();

    public async Task<UserDto?> UpdateAsync(int id, UserUpdateDto dto)
    {
        var u = await db.Users.FindAsync(id);
        if (u == null) return null;
        u.Name = dto.Name; u.Email = dto.Email;
        u.Role = dto.Role; u.IsActive = dto.IsActive;
        await db.SaveChangesAsync();
        cache.Remove(AgentsCacheKey); // роль/активність могли змінити склад агентів
        return u.ToDto();
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var u = await db.Users.FindAsync(id);
        if (u == null) return false;
        db.Users.Remove(u);
        await db.SaveChangesAsync();
        cache.Remove(AgentsCacheKey);
        return true;
    }
}

// ── CommentService ────────────────────────────────────────────────────────────
public class CommentService(IAppDbContext db) : ICommentService
{
    public async Task<CommentDto> AddAsync(int ticketId, CreateCommentDto dto, int userId)
    {
        var comment = new Comment { TicketId = ticketId, Text = dto.Text, UserId = userId };
        db.Comments.Add(comment);
        await db.SaveChangesAsync();
        var full = await db.Comments.Include(c => c.User).FirstAsync(c => c.Id == comment.Id);
        return full.ToDto();
    }

    public async Task<bool> DeleteAsync(int commentId, int userId, string userRole)
    {
        var c = await db.Comments.FindAsync(commentId);
        if (c == null) return false;
        if (userRole != "Admin" && c.UserId != userId)
            throw new ForbiddenAccessException("Ви можете видаляти лише власні коментарі");
        db.Comments.Remove(c);
        await db.SaveChangesAsync();
        return true;
    }
}

// ── StatsService ──────────────────────────────────────────────────────────────
// Уся агрегація виконується в SQL (GroupBy/Count перекладаються у GROUP BY/COUNT).
// Раніше сервіс завантажував ВСІ заявки в пам'ять і рахував там — це переставало
// б масштабуватись зі зростанням кількості заявок.
public class StatsService(IAppDbContext db) : IStatsService
{
    public async Task<StatsDto> GetStatsAsync()
    {
        var statusCounts = await db.Tickets.AsNoTracking()
            .GroupBy(t => t.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync();

        int CountOf(TicketStatus s) => statusCounts.FirstOrDefault(x => x.Status == s)?.Count ?? 0;
        var total = statusCounts.Sum(x => x.Count);

        var byCategory = await db.Tickets.AsNoTracking()
            .GroupBy(t => new { t.Category.Name, t.Category.Color })
            .Select(g => new CategoryStatDto(g.Key.Name, g.Key.Color, g.Count()))
            .ToListAsync();

        var byAgent = await db.Tickets.AsNoTracking()
            .Where(t => t.AssignedTo != null)
            .GroupBy(t => new { t.AssignedTo!.Id, t.AssignedTo.Name })
            .Select(g => new AgentStatDto(
                g.Key.Name,
                g.Count(),
                g.Count(t => t.Status == TicketStatus.Resolved || t.Status == TicketStatus.Closed)
            )).ToListAsync();

        return new StatsDto(
            total,
            CountOf(TicketStatus.New),
            CountOf(TicketStatus.InProgress),
            CountOf(TicketStatus.Resolved),
            CountOf(TicketStatus.Closed),
            byCategory, byAgent
        );
    }
}

// ── AttachmentService ─────────────────────────────────────────────────────────
// Файли зберігаються на диску (не в БД як byte[]), у БД — лише метадані.
// Це дешевше для PostgreSQL і не заважає індексам/бекапам основних таблиць.
public class AttachmentService(IAppDbContext db, IConfiguration config) : IAttachmentService
{
    private const long MaxFileSizeBytes = 10 * 1024 * 1024; // 10 МБ

    // Каталог зберігання беремо з конфігурації (Storage:AttachmentsRoot),
    // за замовчуванням — App_Data/attachments поруч із робочою директорією процесу.
    private string RootPath => Path.Combine(
        Directory.GetCurrentDirectory(),
        config["Storage:AttachmentsRoot"] ?? "App_Data/attachments");

    public async Task<AttachmentDto> UploadAsync(int ticketId, UploadAttachmentRequest request, int userId)
    {
        var ticketExists = await db.Tickets.AnyAsync(t => t.Id == ticketId);
        if (!ticketExists) throw new KeyNotFoundException("Заявку не знайдено");

        if (request.Length <= 0)
            throw new InvalidOperationException("Файл порожній");
        if (request.Length > MaxFileSizeBytes)
            throw new InvalidOperationException($"Максимальний розмір файлу — {MaxFileSizeBytes / 1024 / 1024} МБ");

        Directory.CreateDirectory(RootPath);

        var storedFileName = $"{Guid.NewGuid():N}{Path.GetExtension(request.FileName)}";
        var fullPath = Path.Combine(RootPath, storedFileName);

        await using (var fs = new FileStream(fullPath, FileMode.Create, FileAccess.Write))
            await request.Content.CopyToAsync(fs);

        var attachment = new Attachment
        {
            TicketId = ticketId,
            FileName = request.FileName,
            StoredFileName = storedFileName,
            ContentType = string.IsNullOrWhiteSpace(request.ContentType) ? "application/octet-stream" : request.ContentType,
            FileSizeBytes = request.Length,
            UploadedById = userId
        };
        db.Attachments.Add(attachment);
        await db.SaveChangesAsync();

        var full = await db.Attachments.Include(a => a.UploadedBy).FirstAsync(a => a.Id == attachment.Id);
        return full.ToDto();
    }

    public async Task<AttachmentDownload?> DownloadAsync(int ticketId, int id, int userId, string userRole)
    {
        var a = await db.Attachments.AsNoTracking().Include(x => x.Ticket)
            .FirstOrDefaultAsync(x => x.Id == id);
        // Файл має належати саме тому квитку, що вказаний у маршруті —
        // інакше id вкладення з іншої заявки теж підійшов би (некоректний скоуп).
        if (a == null || a.TicketId != ticketId) return null;

        // Заявку з таким id знайдено, і вкладення справді належить їй — але саму заявку
        // може бути створено іншим користувачем: без цієї перевірки User міг би скачати
        // чужий файл, просто підставивши в URL правильну пару ticketId/attachmentId.
        if (userRole == "User" && a.Ticket.CreatedById != userId)
            throw new ForbiddenAccessException("Ви можете завантажувати лише вкладення власних заявок");

        var fullPath = Path.Combine(RootPath, a.StoredFileName);
        if (!File.Exists(fullPath)) return null;

        return new AttachmentDownload(File.OpenRead(fullPath), a.ContentType, a.FileName);
    }

    public async Task<bool> DeleteAsync(int ticketId, int id, int userId, string userRole)
    {
        var a = await db.Attachments.FindAsync(id);
        if (a == null || a.TicketId != ticketId) return false;

        if (userRole != "Admin" && a.UploadedById != userId)
            throw new ForbiddenAccessException("Ви можете видаляти лише власні файли");

        db.Attachments.Remove(a);
        await db.SaveChangesAsync();

        var fullPath = Path.Combine(RootPath, a.StoredFileName);
        if (File.Exists(fullPath)) File.Delete(fullPath);

        return true;
    }
}
