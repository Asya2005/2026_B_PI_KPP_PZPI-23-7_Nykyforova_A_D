using ServiceDesk.Application.DTOs;

namespace ServiceDesk.Application.Interfaces;

public interface IAuthService
{
    Task<AuthResponseDto> LoginAsync(LoginDto dto);
    Task<AuthResponseDto> RegisterAsync(RegisterDto dto);
}

public interface ITicketService
{
    Task<PagedResult<TicketDto>> GetAllAsync(TicketFilterParams filter, int currentUserId, string currentUserRole);
    Task<TicketDetailDto?> GetByIdAsync(int id);
    Task<TicketDetailDto?> GetByIdAsync(int id, int currentUserId, string currentUserRole);
    Task<TicketDto> CreateAsync(CreateTicketDto dto, int userId);
    Task<TicketDto?> UpdateAsync(int id, UpdateTicketDto dto, int userId, string userRole);
    Task<bool> DeleteAsync(int id, string userRole);
    Task<TicketDto?> ChangeStatusAsync(int id, ChangeStatusDto dto, int userId, string userRole);
    Task<TicketDto?> AssignAsync(int id, AssignTicketDto dto, string userRole);
}

public interface ICategoryService
{
    Task<List<CategoryDto>> GetAllAsync();
    Task<CategoryDto?> GetByIdAsync(int id);
    Task<CategoryDto> CreateAsync(CreateCategoryDto dto);
    Task<CategoryDto?> UpdateAsync(int id, UpdateCategoryDto dto);
    Task<bool> DeleteAsync(int id);
}

public interface IUserService
{
    Task<List<UserDto>> GetAllAsync();
    Task<List<UserDto>> GetAgentsAsync();
    Task<UserDto?> GetByIdAsync(int id);
    Task<UserDto?> UpdateAsync(int id, UserUpdateDto dto);
    Task<bool> DeleteAsync(int id);
}

public interface ICommentService
{
    Task<CommentDto> AddAsync(int ticketId, CreateCommentDto dto, int userId);
    Task<bool> DeleteAsync(int commentId, int userId, string userRole);
}

public interface IStatsService
{
    Task<StatsDto> GetStatsAsync();
}

public interface IAttachmentService
{
    Task<AttachmentDto> UploadAsync(int ticketId, UploadAttachmentRequest request, int userId);
    Task<AttachmentDownload?> DownloadAsync(int ticketId, int id, int userId, string userRole);
    Task<bool> DeleteAsync(int ticketId, int id, int userId, string userRole);
}
