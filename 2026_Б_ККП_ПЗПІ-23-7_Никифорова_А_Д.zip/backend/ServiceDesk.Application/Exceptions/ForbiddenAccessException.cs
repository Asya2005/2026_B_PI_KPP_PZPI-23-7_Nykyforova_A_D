namespace ServiceDesk.Application.Exceptions;

/// <summary>
/// Кидається сервісним шаром, коли користувач автентифікований, але не має прав
/// на конкретну дію (на відміну від "не знайдено" — це різні HTTP-статуси: 403 проти 404).
/// </summary>
public class ForbiddenAccessException(string message) : Exception(message);
