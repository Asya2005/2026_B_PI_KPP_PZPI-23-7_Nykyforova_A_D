# 🛡️ Service Desk — Система обліку заявок

Повний стек: ASP.NET Core 9 + PostgreSQL + React + Vite

---

## ⚡ Швидкий старт

### 1. База даних (PostgreSQL)
Відкрити pgAdmin або psql і переконатись що PostgreSQL запущено.
Нічого не треба створювати вручну — міграції запустяться автоматично.

За замовчуванням використовується:
- Host: localhost:5432
- Database: servicedesk
- Username: postgres
- Password: postgres

У випдку інших налаштувань — треба відредагувати у файлі:
`backend/ServiceDesk.API/appsettings.json`

### 2. Бекенд (Visual Studio / командний рядок)

**Варіант A — Visual Studio:**
1. Відкрити `backend/ServiceDesk.sln`
2. Встановити `ServiceDesk.API` як стартовий проєкт
3. Натиснути F5 або Ctrl+F5

**Варіант B — Термінал:**
```bash
cd backend/ServiceDesk.API
dotnet run
```

Бекенд запуститься на: http://localhost:5000
Swagger UI: http://localhost:5000/swagger

### 3. Фронтенд (VS Code / термінал)

```bash
cd frontend
npm install
npm run dev
```

Відкрити: http://localhost:5173

---

## 🔑 Тестові акаунти

| Роль          | Email                     | Пароль    |
|---------------|---------------------------|-----------|
| Адміністратор | admin@servicedesk.ua      | Admin123! |
| Агент         | agent@servicedesk.ua      | Agent123! |
| Користувач    | user@servicedesk.ua       | User123!  |

---

## 📁 Структура проєкту

```
servicedesk/
├── backend/
│   ├── ServiceDesk.sln
│   ├── ServiceDesk.Domain/       ← Сутності та enum'и
│   ├── ServiceDesk.Application/  ← Сервіси, DTOs, інтерфейси
│   ├── ServiceDesk.Infrastructure/← DbContext, репозиторії
│   └── ServiceDesk.API/          ← Контролери, Program.cs
└── frontend/
    ├── src/
    │   ├── api/        ← Axios запити
    │   ├── context/    ← AuthContext
    │   ├── components/ ← Layout, shared компоненти
    │   └── pages/      ← Всі сторінки
    └── package.json
```

---

## 🚀 Функціональність

- ✅ Реєстрація та вхід (JWT)
- ✅ Три ролі: User, Agent, Admin
- ✅ CRUD заявок з фільтрацією, сортуванням, пагінацією
- ✅ Зміна статусу з логуванням (TicketStatusHistory)
- ✅ Призначення агента на заявку
- ✅ Коментарі до заявок
- ✅ Статистика (для агентів і адмінів)
- ✅ Управління користувачами (адмін)
- ✅ Управління категоріями (адмін)
- ✅ Темна тема, адаптивний дизайн
